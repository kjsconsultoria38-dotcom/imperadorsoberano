import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
const file = process.env.DATABASE_PATH || './data/imperator.db';
if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), {recursive:true});
export const db = new Database(file);
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'admin',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS leads(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT,company TEXT,status TEXT NOT NULL DEFAULT 'new',source TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS campaigns(id INTEGER PRIMARY KEY,name TEXT NOT NULL,channel TEXT NOT NULL DEFAULT 'unknown',spend REAL NOT NULL DEFAULT 0,clicks INTEGER NOT NULL DEFAULT 0,conversions INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'planned',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS revenue_records(id INTEGER PRIMARY KEY,external_id TEXT UNIQUE,amount REAL NOT NULL,currency TEXT NOT NULL DEFAULT 'BRL',status TEXT NOT NULL DEFAULT 'confirmed',source TEXT,occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tracking_events(id INTEGER PRIMARY KEY,event_name TEXT NOT NULL,anonymous_id TEXT,lead_id INTEGER,source TEXT,medium TEXT,campaign TEXT,payload_json TEXT NOT NULL DEFAULT '{}',occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(lead_id) REFERENCES leads(id));
CREATE TABLE IF NOT EXISTS agent_runs(id INTEGER PRIMARY KEY,agent_id TEXT NOT NULL,status TEXT NOT NULL,input_json TEXT NOT NULL DEFAULT '{}',output_json TEXT NOT NULL DEFAULT '{}',started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,finished_at TEXT);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY,actor_email TEXT,action TEXT NOT NULL,resource TEXT NOT NULL,details_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
`);
const email=(process.env.ADMIN_EMAIL||'').trim().toLowerCase(), password=process.env.ADMIN_PASSWORD||'';
if(email && password && !db.prepare('SELECT id FROM users WHERE email=?').get(email)) db.prepare('INSERT INTO users(email,password_hash,role) VALUES(?,?,?)').run(email,bcrypt.hashSync(password,12),'admin');
