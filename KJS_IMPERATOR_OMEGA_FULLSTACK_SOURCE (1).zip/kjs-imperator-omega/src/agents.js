export const agents=[
{id:'imperator_orchestrator',name:'Imperator Orchestrator',version:'1.0.0',purpose:'Priorizar tarefas, validar pré-condições e consolidar resultados.',permissions:['read:metrics','write:agent_runs']},
{id:'revenue_core',name:'Revenue Core',version:'1.0.0',purpose:'Calcular métricas a partir de registros locais confirmados.',permissions:['read:revenue','read:campaigns']},
{id:'utm_revenue_tracker',name:'UTM Revenue Tracker',version:'1.0.0',purpose:'Registrar eventos e parâmetros de atribuição recebidos.',permissions:['write:tracking_events']},
{id:'spy_intelligence',name:'Spy Intelligence',version:'1.0.0',purpose:'Organizar observações de fontes públicas com proveniência explícita.',permissions:['read:public_sources']},
{id:'sovereign_cyber_defense',name:'Sovereign Cyber Defense',version:'1.0.0',purpose:'Verificar controles básicos de configuração e segurança.',permissions:['read:security_status']}
];
export function runAgent(id,input={}){const a=agents.find(x=>x.id===id);if(!a)return{ok:false,error:'AGENT_NOT_FOUND'};return{ok:true,agent_id:a.id,version:a.version,status:'COMPLETED',evidence_class:'LOCAL_WORKFLOW',result:{message:`Workflow local de ${a.name} executado.`,received_keys:Object.keys(input).slice(0,30),external_integrations:'NOT_CONNECTED'}};}
