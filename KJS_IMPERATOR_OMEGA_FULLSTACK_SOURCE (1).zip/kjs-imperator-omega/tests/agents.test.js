import test from 'node:test'; import assert from 'node:assert/strict'; import {agents,runAgent} from '../src/agents.js';
test('agent IDs are unique',()=>{const ids=agents.map(a=>a.id);assert.equal(new Set(ids).size,ids.length);});
test('known agent runs bounded local workflow',()=>{const r=runAgent('imperator_orchestrator',{goal:'test'});assert.equal(r.ok,true);assert.equal(r.status,'COMPLETED');assert.equal(r.result.external_integrations,'NOT_CONNECTED');});
test('unknown agent is rejected',()=>assert.equal(runAgent('not-real').error,'AGENT_NOT_FOUND'));
