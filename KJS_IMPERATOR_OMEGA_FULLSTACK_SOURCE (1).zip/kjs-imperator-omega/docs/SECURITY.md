# Baseline de segurança
- Use JWT_SECRET aleatório com pelo menos 32 caracteres e senha administrativa exclusiva.
- Segredos somente em variáveis de ambiente ou cofre do provedor; nunca commitar `.env`.
- HTTPS em produção e CORS restrito ao domínio real.
- SQLite serve para desenvolvimento/instância única; produção multi-instância deve usar banco gerenciado e backups testados.
- Ative secret scanning, alertas de dependência e revisão de permissões no GitHub.
- Teste restauração de backup, expiração de token, autorização, rate limits e resposta a incidentes.
- Nenhum sistema é invulnerável; isso é baseline, não certificação de segurança.
