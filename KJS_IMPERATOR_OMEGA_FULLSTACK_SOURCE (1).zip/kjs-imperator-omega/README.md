# KJS IMPERATOR Ω — Full-stack source
**KJS Consultoria Comercial · Kamillo de Jesus Santos · #KamilloSantosProtocol**

Aplicação full-stack inicial executável: dashboard HTML/CSS/JS, API REST Express, SQLite, autenticação JWT, validação Zod, trilha de auditoria, registro de agentes, testes e CI. Este código é uma base funcional de MVP; não significa que APIs de publicidade, CRM, IA ou inteligência de mercado estejam conectadas.

## Executar localmente
1. Instale Node.js 20+.
2. Copie `.env.example` para `.env`.
3. Defina `JWT_SECRET` com pelo menos 32 caracteres aleatórios e troque `ADMIN_PASSWORD`.
4. Execute `npm install` e depois `npm start`.
5. Abra `http://localhost:3000` e autentique com `ADMIN_EMAIL`/`ADMIN_PASSWORD`.

## API
`GET /api/health`; `POST /api/auth/login`; autenticadas: `GET /api/dashboard`, `GET/POST /api/leads`, `GET/POST /api/campaigns`, `GET/POST /api/revenue`, `GET/POST /api/events`, `GET /api/agents`, `POST /api/agents/:id/run` (admin), `GET /api/audit` (admin). Use `Authorization: Bearer <token>`.

## GitHub
Suba todos os arquivos e diretórios deste projeto para a raiz do repositório. O GitHub Pages serve arquivos estáticos e **não executa este backend**. Para full-stack, use um host Node.js com armazenamento persistente e configure as variáveis de ambiente no painel do host. Não publique `.env`.

## Limites atuais
Os agentes são workflows locais controlados. Integrações externas, conectores de dados, execução real de modelos e automações de plataformas ainda exigem implementação, credenciais, autorização e testes próprios. Não implante em produção sem revisar persistência, backups, monitoramento, segurança e dependências.
